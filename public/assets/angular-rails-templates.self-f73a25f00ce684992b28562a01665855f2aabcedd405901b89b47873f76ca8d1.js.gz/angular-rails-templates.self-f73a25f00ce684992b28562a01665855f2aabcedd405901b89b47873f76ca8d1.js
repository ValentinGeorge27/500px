// Angular Rails Templates 1.0.0
//
// angular_templates.ignore_prefix: ["templates/"]
// angular_templates.markups: ["erb", "str"]
// angular_templates.htmlcompressor: 

angular.module("templates", []);

